/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Kowalczyk
 */
public class LogWindow{
    
    public JFrame frame;
    public JPanel panel;
    public JTextField logBox;
    public JPasswordField passBox;
    public JButton bConfirm;
    public JLabel logLab,passLab;
    
    public LogWindow()
    {
        frame=new JFrame("Login");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        panel= new JPanel();
        panel.setSize(400, 200);
        panel.setLayout(null);
        frame.add(panel);
        logBox = new JTextField();
        logBox.setBounds(140, 35, 200, 30);
        logLab = new JLabel("Login:");
        logLab.setBounds(90, 35, 45, 30);
        passBox = new JPasswordField();
        passBox.setBounds(140, 75, 200, 30);
        passLab = new JLabel("Password:");
        passLab.setBounds(65, 75, 80, 30);
        bConfirm = new JButton("Confirm");
        bConfirm.setBounds(160,120,80,30);
        panel.add(logBox);
        panel.add(logLab);
        panel.add(passBox);
        panel.add(passLab);
        panel.add(bConfirm);
        frame.setVisible(true);
    }
    
}
