package clinic;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VisitWindow {
    public JFrame frame;
    public JPanel panel;
    public JTextField idBox,nameBox,bDateBox,vDateBox,hourBox,docBox;
    public JButton bConfirm;
    public JLabel idLabel,nameLabel,bDateLabel,vDateLabel,hourLabel,docLabel;
    public Boolean newOne;
    
    public VisitWindow()
    {
        newOne=false;
        frame=new JFrame("Visit");
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);
        frame.setSize(400,400);
        frame.setLocationRelativeTo(null);
        panel = new JPanel();
        panel.setLayout(null);
        panel.setSize(300,400);
        frame.add(panel);
        docLabel=new JLabel("Doctor");
        docLabel.setBounds(50,40,140,30);
        panel.add(docLabel);
        vDateLabel=new JLabel("Date");
        vDateLabel.setBounds(50,80,140,30);
        panel.add(vDateLabel);
        hourLabel=new JLabel("Hour");
        hourLabel.setBounds(50,120,140,30);
        panel.add(hourLabel);
        idLabel=new JLabel("Patient ID");
        idLabel.setBounds(50,160,140,30);
        panel.add(idLabel);
        nameLabel=new JLabel("Name");
        nameLabel.setBounds(50,200,140,30);
        panel.add(nameLabel);
        bDateLabel=new JLabel("Birthdate");
        bDateLabel.setBounds(50,240,140,30);
        panel.add(bDateLabel);
        docBox=new JTextField();
        docBox.setBounds(150,40,200,30);
        panel.add(docBox);
        vDateBox=new JTextField();
        vDateBox.setBounds(150,80,200,30);
        panel.add(vDateBox);
        hourBox=new JTextField();
        hourBox.setBounds(150,120,200,30);
        panel.add(hourBox);
        idBox=new JTextField();
        idBox.setBounds(150,160,200,30);
        panel.add(idBox);
        nameBox=new JTextField();
        nameBox.setBounds(150,200,200,30);
        nameBox.setEnabled(false);
        panel.add(nameBox);
        bDateBox=new JTextField();
        bDateBox.setBounds(150,240,200,30);
        bDateBox.setEnabled(false);
        panel.add(bDateBox);
        bConfirm = new JButton("Confirm");
        bConfirm.setBounds(150,300,100,30);
        panel.add(bConfirm);
        frame.setVisible(false);
    }
    
    public void unlock(boolean l)
    {
        nameBox.setEnabled(l);
        bDateBox.setEnabled(l);
    }
    
}
