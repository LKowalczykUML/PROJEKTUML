/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Kowalczyk
 */
public class SelectWindow implements ActionListener{
    
    JFrame frame;
    JPanel panel;
    JButton bUp,bDown,bConfirm;
    JTextField displayBox;
    int curPos;
    ArrayList<String> resultList;
    
    public SelectWindow(ArrayList<Doctor> docL)
    {
        curPos=0;
        resultList = new ArrayList<>();
        for(Doctor d:docL)
            resultList.add(d.getName()+" - "+d.getSpecs());
        frame = new JFrame("Select Doctor");
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        panel = new JPanel();
        panel.setSize(400,200);
        panel.setLayout(null);
        frame.add(panel);
        displayBox = new JTextField(resultList.get(curPos));
        displayBox.setEditable(false);
        displayBox.setBounds(50,50,300,30);
        panel.add(displayBox);
        bUp = new JButton("UP");
        bUp.setBounds(50,100,90,30);
        bUp.addActionListener(this);
        panel.add(bUp);
        bDown = new JButton("DOWN");
        bDown.setBounds(150,100,90,30);
        bDown.addActionListener(this);
        panel.add(bDown);
        bConfirm = new JButton("Confirm");
        bConfirm.setBounds(250,100,90,30);
        panel.add(bConfirm);
        frame.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object src = ae.getSource();
        if(src==bUp && curPos<resultList.size()-1)
            curPos+=1;
        if(src==bDown && curPos>0)
            curPos-=1;
        displayBox.setText(resultList.get(curPos));
    }
    
    void update(ArrayList<Doctor> docL)
    {
        if(docL.size()>resultList.size())
        {
            for(int i=resultList.size();i<docL.size();i++)
                resultList.add(docL.get(i).getName()+" - "+docL.get(i).getSpecs());
        }
    }
}
