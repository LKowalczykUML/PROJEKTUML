/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

/**
 *
 * @author Kowalczyk
 */
public class Date2 {
    
    private int day,month,year;
    public Date2(int d,int m,int y)
    {
        day=d;
        month=m;
        year=y;
    }
    
    public Date2(String date)
    {
        day=Integer.parseInt(date.substring(0,2));
        month=Integer.parseInt(date.substring(3,5));
        year=Integer.parseInt(date.substring(6,10));
    }
    
    public Date2(Date2 d)
    {
        day=d.getDay();
        month=d.getMonth();
        year=d.getYear();
    }
    
    public String printDate()
    {
        String d,m;
        if(day<10)
            d="0"+String.valueOf(day);
        else
            d=String.valueOf(day);
        if(month<10)
            m="0"+String.valueOf(month);
        else
            m=String.valueOf(month);
        return d+"/"+m+"/"+String.valueOf(year);
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }
    
    public void raise(int t)
    {
        for(int i=0;i<t;i++)
        {
            day+=1;
            if(month==1 || month==3 || month==5 || month==7 ||month==8||month==10||month==12)
            {
                if(day==32)
                {
                    day=1;
                    month+=1;
                }
            }
            else
            {
                if(month==2)
                {
                    if(day==29 && year%4!=0)
                    {
                        day=1;
                        month+=1;
                    }
                    if(day==30)
                    {
                        day=1;
                        month+=1;
                    }
                }
                else
                {
                    if(day==31)
                    {
                        day=1;
                        month+=1;
                    }
                }
            }
            if(month==13)
            {
                month=1;
                year+=1;
            }
        }
    }
    
    boolean equals(Date2 date)
    {
        if(date.getDay()==day && date.getMonth()==month && date.getYear()==year)
            return true;
        else
            return false;
    }
}
