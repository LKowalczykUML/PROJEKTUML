/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

/**
 *
 * @author Kowalczyk
 */
public class Doctor extends User{
    
    private int doctorID;
    private String specs;
    private Roster roster;
    public Doctor(String nm,String BDay,String Pass,String Spec,int id)
    {
        super(nm,BDay,("D"+String.valueOf(id)),Pass);
        doctorID=id;
        specs=Spec;
        roster= new Roster();
    }

    public int getDoctorID() {
        return doctorID;
    }

    public String getSpecs() {
        return specs;
    }
    
    public Roster getRoster() {
        return roster;
    }
    
}
