package clinic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Clinic {

    private static ArrayList<Patient> patientList;
    private static ArrayList<Doctor> doctorList;
    private static ArrayList<DeskClerck> deskClerckList;
    private static String CurrentAcc;
    private static int CurrentID;
    private static LogWindow LogW;
    private static OptionWindow OpW;
    private static VisitWindow VisW;
    private static AdditionWindow AddW;
    private static SelectWindow SelW;
    private static EditWindow EdW;
    
    public static void loadData()
    {
        String line=null;
        try
        {
           FileReader reader= new FileReader("data/doctors.txt");
           BufferedReader bReader= new BufferedReader(reader);
           while((line=bReader.readLine())!=null)
           {
               String ID,name,pass,bd,spec;
               ID=line;
               line=bReader.readLine();
               name=line;
               line=bReader.readLine();
               pass=line;
               line=bReader.readLine();
               bd=line;
               line=bReader.readLine();
               spec=line.toLowerCase();
               Doctor d=new Doctor(name,bd,pass,spec,Integer.parseInt(ID));
               doctorList.add(d);
           }
           
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        line=null;
        try
        {
           FileReader reader= new FileReader("data/clercks.txt");
           BufferedReader bReader= new BufferedReader(reader);
           while((line=bReader.readLine())!=null)
           {
               String ID,name,pass,bd;
               ID=line;
               line=bReader.readLine();
               name=line;
               line=bReader.readLine();
               pass=line;
               line=bReader.readLine();
               bd=line;
               DeskClerck c=new DeskClerck(name,bd,pass,Integer.parseInt(ID));
               deskClerckList.add(c);
           }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        line=null;
        try
        {
           FileReader reader= new FileReader("data/patients.txt");
           BufferedReader bReader= new BufferedReader(reader);
           while((line=bReader.readLine())!=null)
           {
               String ID,name,pass,bd,spec;
               ID=line;
               line=bReader.readLine();
               name=line;
               line=bReader.readLine();
               bd=line;
               Patient p=new Patient(name,bd,Integer.parseInt(ID));
               patientList.add(p);
           }
           
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        line=null;
        try
        {
           FileReader reader= new FileReader("data/rosters.txt");
           BufferedReader bReader= new BufferedReader(reader);
           while((line=bReader.readLine())!=null)
           {
               String ID,amo;
               ID=line;
               line=bReader.readLine();
               amo=line;
               for(int i=0;i<Integer.parseInt(amo);i++)
               {
                   String name,date,hour;
                   line=bReader.readLine();
                   name=line;
                   line=bReader.readLine();
                   date=line;
                   line=bReader.readLine();
                   hour=line;
                   RosterEntry r = new RosterEntry(date,name,Integer.parseInt(hour));
                   doctorList.get(Integer.parseInt(ID)-20001).getRoster().addEntry(r);
               }
           }
           
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    public static void saveData(boolean cb,boolean db,boolean pb,boolean rb)
    {
        if(db)
        {
            try{
                PrintWriter writer= new PrintWriter("data/doctors.txt","UTF-8");
                for(Doctor d:doctorList)
                {
                    writer.println(d.getDoctorID());
                    writer.println(d.getName());
                    writer.println(d.getPassword());
                    writer.println(d.getBirthdate());
                    writer.println(d.getSpecs());
                }
                writer.close();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
        if(cb)
        {
            try{
                PrintWriter writer= new PrintWriter("data/clercks.txt","UTF-8");
                for(DeskClerck d:deskClerckList)
                {
                    writer.println(d.getClerckID());
                    writer.println(d.getName());
                    writer.println(d.getPassword());
                    writer.println(d.getBirthdate());
                }
                writer.close();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
        if(pb)
        {
            try{
                PrintWriter writer= new PrintWriter("data/patients.txt","UTF-8");
                for(Patient d:patientList)
                {
                    writer.println(d.getPatientID());
                    writer.println(d.getName());
                    writer.println(d.getBirthdate());
                }
                writer.close();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
        if(rb)
        {
            try{
                PrintWriter writer= new PrintWriter("data/rosters.txt","UTF-8");
                for(Doctor d:doctorList)
                {
                    writer.println(d.getDoctorID());
                    writer.println(d.getRoster().getSize());
                    for(int i=0;i<d.getRoster().getSize();i++)
                    {
                        writer.println(d.getRoster().getEntry(i).patientName);
                        writer.println(d.getRoster().getEntry(i).visitDate.printDate());
                        writer.println(d.getRoster().getEntry(i).hour);
                    }
                }
                writer.close();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
    }
    
    static class ButtonControler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            Object src=ae.getSource();
            if(src==LogW.bConfirm)
            {
                String l,p;
                l=LogW.logBox.getText();
                p=LogW.passBox.getText();
                boolean success=false;
                if(l.charAt(0)=='D')
                {
                    int counter=0;
                    for(Doctor d:doctorList)
                    {
                        if(d.getLogin().equals(l))
                        {
                            if(d.getPassword().equals(p))
                            {
                                CurrentAcc="Doctor";
                                CurrentID=counter;
                                success=true;
                            }
                            break;
                        }
                        counter++;
                    }
                }
                if(l.charAt(0)=='C')
                {
                    int counter=0;
                    for(DeskClerck c:deskClerckList)
                    {
                        if(c.getLogin().equals(l))
                        {
                            if(c.getPassword().equals(p))
                            {
                                CurrentAcc="DeskClerck";
                                CurrentID=counter;
                                success=true;
                            }
                            break;
                        }
                        counter++;
                    }
                }
                if(!success)
                {
                    JOptionPane.showMessageDialog(LogW.frame, "Incorrect Password or Login","Display Message",JOptionPane.WARNING_MESSAGE);
                    LogW.passBox.setText("");
                }
                else
                {
                    LogW.frame.setVisible(false);
                    OpW.lockButtons(CurrentAcc);
                    OpW.frame.setVisible(true);
                    
                }
            }
            if(src==OpW.buttonList.get(0))
            {
                //Log out
                OpW.frame.setVisible(false);
                LogW.logBox.setText("");
                LogW.passBox.setText("");
                LogW.frame.setVisible(true);
            }
            if(src==OpW.buttonList.get(1))
            {
                //Add visit p1
                VisW.unlock(false);
                VisW.bDateBox.setText("");
                VisW.docBox.setText("");
                VisW.hourBox.setText("");
                VisW.idBox.setText("");
                VisW.nameBox.setText("");
                VisW.vDateBox.setText("");
                VisW.newOne=false;
                VisW.frame.setVisible(true);
            }
            if(src==VisW.bConfirm)
            {
                //Add visit p2
                int id=Integer.parseInt(VisW.idBox.getText());
                if(!VisW.newOne)
                {
                    if(id<=patientList.size())
                    {
                        boolean success=false;
                        for(Doctor D:doctorList)
                        {
                            if(D.getSpecs().equals(VisW.docBox.getText().toLowerCase()))
                            {
                                RosterEntry r = new RosterEntry(VisW.vDateBox.getText(),
                                        patientList.get(Integer.parseInt(VisW.idBox.getText())-1).getName(),Integer.parseInt(VisW.hourBox.getText()));
                                D.getRoster().addEntry(r);
                                JOptionPane.showMessageDialog(LogW.frame, "Visit date: "+r.visitDate.printDate()+" "+r.hour+":00"
                                        ,"Information",JOptionPane.INFORMATION_MESSAGE);
                                success=true;
                                break;
                            }
                        }
                        if(!success)
                        {
                            JOptionPane.showMessageDialog(LogW.frame, "There is no specified doctor","Information",JOptionPane.INFORMATION_MESSAGE);
                        }
                        else
                        {
                            VisW.frame.setVisible(false);
                            saveData(false,false,false,true);
                        }
                    }
                    else
                    {
                        VisW.newOne=true;
                        VisW.unlock(true);
                    }
                }
                else
                {
                    Patient p=new Patient(VisW.nameBox.getText(),VisW.bDateBox.getText(),patientList.size()+1);
                    patientList.add(p);
                    boolean success=false;
                    for(Doctor D:doctorList)
                    {
                        if(D.getSpecs().equals(VisW.docBox.getText().toLowerCase()))
                        {
                            RosterEntry r = new RosterEntry(VisW.vDateBox.getText(),VisW.nameBox.getText(),Integer.parseInt(VisW.hourBox.getText()));
                            D.getRoster().addEntry(r);
                            JOptionPane.showMessageDialog(LogW.frame, "Visit date: "+r.visitDate.printDate()+" "+r.hour+":00"
                                    ,"Information",JOptionPane.INFORMATION_MESSAGE);
                            success=true;
                            break;
                        }
                    }
                    if(!success)
                        JOptionPane.showMessageDialog(LogW.frame, "There is no specified doctor","Information",JOptionPane.INFORMATION_MESSAGE);
                    else
                    {
                        VisW.frame.setVisible(false);
                        saveData(false,false,true,true);
                    }
                }
            }
            if(src==OpW.buttonList.get(2))
            {
                //Add doctor p1
                AddW.dateBox.setText("");
                AddW.nameBox.setText("");
                AddW.specBox.setText("");
                AddW.passBox.setText("");
                AddW.frame.setVisible(true);
            }
            if(src==AddW.bConfirm)
            {
                //Add doctor p2
                Doctor d = new Doctor(AddW.nameBox.getText(),AddW.dateBox.getText(),AddW.passBox.getText(),
                        AddW.specBox.getText().toLowerCase(),doctorList.size()+20001);
                doctorList.add(d);
                AddW.frame.setVisible(false);
                saveData(false,true,false,false);
            }
            if(src==OpW.buttonList.get(3))
            {
                //Display Doctor roster p1
                SelW.update(doctorList);
                SelW.frame.setVisible(true);
            }
            if(src==SelW.bConfirm)
            {
                //Display Doctor roster p2
                doctorList.get(SelW.curPos).getRoster().printRoster();
                SelW.frame.setVisible(false);
            }
            if(src==OpW.buttonList.get(4))
            {
                //Display roster
                doctorList.get(CurrentID).getRoster().printRoster();
            }
            if(src==OpW.buttonList.get(5))
            {
                //Examine patient
                doctorList.get(CurrentID).getRoster().removeEntry(0);
                saveData(false,false,false,true);
            }
            if(src==OpW.buttonList.get(6))
            {
                //change visit p1
                EdW.dateBox.setText("");
                EdW.docBox.setText("");
                EdW.hourBox.setText("");
                EdW.nameBox.setText("");
                EdW.frame.setVisible(true);
            }
            if(src==EdW.bConfirm)
            {
                //change visit p2;
                for(Doctor d:doctorList)
                {
                    if(d.getSpecs().equals(EdW.docBox.getText()))
                    {
                        int i=0;
                        while(i<d.getRoster().getSize())
                        {
                            if(d.getRoster().getEntry(i).patientName.equals(EdW.nameBox.getText()))
                            {
                                d.getRoster().removeEntry(i);
                                RosterEntry r = new RosterEntry(EdW.dateBox.getText(),
                                        EdW.nameBox.getText(),Integer.parseInt(EdW.hourBox.getText()));
                                d.getRoster().addEntry(r);
                                break;
                            }
                            i++;
                        }
                        saveData(false,false,false,true);
                        break;
                    }
                }
                EdW.frame.setVisible(false);
            }
        }
        
    }
    
    public static void main(String[] args) {
        patientList = new ArrayList<>();
        doctorList = new ArrayList<>();
        deskClerckList = new ArrayList<>();
        loadData();
        /*for(Patient p:patientList)
            System.out.println(p.getName()+" "+p.getPatientID());
        for(Doctor d:doctorList)
            System.out.println(d.getName()+" "+d.getLogin()+" "+d.getPassword());
        for(DeskClerck c:deskClerckList)
            System.out.println(c.getName()+" "+c.getLogin()+" "+c.getPassword());*/
        
        ButtonControler controler = new ButtonControler();
        LogW = new LogWindow();
        LogW.bConfirm.addActionListener(controler);
        OpW = new OptionWindow();
        OpW.buttonList.forEach((b) -> {
            b.addActionListener(controler);
        });
        VisW = new VisitWindow();
        VisW.bConfirm.addActionListener(controler);
        AddW = new AdditionWindow();
        AddW.bConfirm.addActionListener(controler);
        SelW = new SelectWindow(doctorList);
        SelW.bConfirm.addActionListener(controler);
        EdW = new EditWindow();
        EdW.bConfirm.addActionListener(controler);
    }
}
