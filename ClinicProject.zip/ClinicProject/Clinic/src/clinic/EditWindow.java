/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Kowalczyk
 */
public class EditWindow {
    public JFrame frame;
    public JPanel panel;
    public JTextField nameBox,dateBox,hourBox,docBox;
    public JButton bConfirm;
    public JLabel nameLabel,dateLabel,hourLabel,docLabel;
   
    public EditWindow()
    {
        frame=new JFrame("Edit");
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);
        frame.setSize(400,300);
        frame.setLocationRelativeTo(null);
        panel = new JPanel();
        panel.setLayout(null);
        panel.setSize(300,300);
        frame.add(panel);
        docLabel=new JLabel("Doctor");
        docLabel.setBounds(50,40,140,30);
        panel.add(docLabel);
        dateLabel=new JLabel("Date");
        dateLabel.setBounds(50,80,140,30);
        panel.add(dateLabel);
        hourLabel=new JLabel("Hour");
        hourLabel.setBounds(50,120,140,30);
        panel.add(hourLabel);
        nameLabel=new JLabel("Patient Name");
        nameLabel.setBounds(50,160,140,30);
        panel.add(nameLabel);
        docBox=new JTextField();
        docBox.setBounds(150,40,200,30);
        panel.add(docBox);
        dateBox=new JTextField();
        dateBox.setBounds(150,80,200,30);
        panel.add(dateBox);
        hourBox=new JTextField();
        hourBox.setBounds(150,120,200,30);
        panel.add(hourBox);
        nameBox=new JTextField();
        nameBox.setBounds(150,160,200,30);
        panel.add(nameBox);
        bConfirm = new JButton("Confirm");
        bConfirm.setBounds(150,210,100,30);
        panel.add(bConfirm);
        frame.setVisible(false);
    }
}
