/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;

/**
 *
 * @author Kowalczyk
 */
public class Roster {
    
    private ArrayList<RosterEntry> entryList;
    private ArrayList<RosterWindow> winList;
    
    public Roster()
    {
        entryList = new ArrayList<>();
        winList = new ArrayList<>();
    }
    
    public void printRoster()
    {
        if(entryList.isEmpty())
            JOptionPane.showMessageDialog(null, "Roster is empty","Ifnormation",JOptionPane.INFORMATION_MESSAGE);
        else
        {
            RosterWindow rw = new RosterWindow(entryList);
            winList.add(rw);
        }
    }
    
    public void addEntry(RosterEntry r)
    {
        int i=0;
        while(i<entryList.size())
        {
            RosterEntry e = entryList.get(i);
            if(e.hour==r.hour && e.visitDate.equals(r.visitDate))
            {
                r.hour+=1;
                if(r.hour>23)
                {
                    r.hour=0;
                    r.visitDate.raise(1);
                }
            }
            else
                i++;
        }
        entryList.add(r);
        Collections.sort(entryList);
    }
    
    public int getSize()
    {
        return entryList.size();
    }
    
    public RosterEntry getEntry(int i)
    {
        return entryList.get(i);
    }
    
    public void removeEntry(int i)
    {
        if(i<entryList.size())
            entryList.remove(i);
    }
}
