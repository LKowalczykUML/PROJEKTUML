/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Kowalczyk
 */
public class OptionWindow {
    
    public JFrame frame;
    public JPanel panel;
    public ArrayList<JButton> buttonList;
    public OptionWindow()
    {
        frame = new JFrame("Option Window");
        frame.setSize(400,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        panel = new JPanel();
        panel.setSize(400, 600);
        panel.setLayout(null);
        frame.add(panel);
        buttonList = new ArrayList<>();

        JButton b0 = new JButton("Log out");
        b0.setBounds(100,50,200,50);
        buttonList.add(b0);
        JButton b1 = new JButton("Add visit");
        b1.setBounds(100,110,200,50);
        b1.setActionCommand("DeskClerck");
        buttonList.add(b1);
        JButton b2 = new JButton("Add doctor");
        b2.setBounds(100,230,200,50);
        b2.setActionCommand("DeskClerck");
        buttonList.add(b2);
        JButton b3 = new JButton("Display doctor's roster");
        b3.setBounds(100,290,200,50);
        b3.setActionCommand("DeskClerck");
        buttonList.add(b3);
        JButton b4 = new JButton("Check roster");
        b4.setActionCommand("Doctor");
        b4.setBounds(100,350,200,50);
        buttonList.add(b4);
        JButton b5 = new JButton("Examine the next patient");
        b5.setBounds(100,410,200,50);
        b5.setActionCommand("Doctor");
        buttonList.add(b5);
        JButton b6 = new JButton("Edit Visit");
        b6.setActionCommand("DeskClerck");
        b6.setBounds(100,170,200,50);
        buttonList.add(b6);
        for(JButton b:buttonList)
            panel.add(b);
    }
    
    public void lockButtons(String AccType)
    {
        for(JButton b:buttonList)
        {
            if(b.getActionCommand().equals(AccType) || b.getText().equals("Log out"))
                b.setEnabled(true);
            else
                b.setEnabled(false);
        }
    }
}
