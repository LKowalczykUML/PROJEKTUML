package clinic;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdditionWindow {
    
    public JFrame frame;
    public JPanel panel;
    public JLabel nameLabel,passLabel,dateLabel,specLabel;
    public JTextField nameBox,dateBox,specBox;
    public JPasswordField passBox;
    public JButton bConfirm;
    
    public AdditionWindow()
    {
        frame = new JFrame("Add Doctor");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        panel = new JPanel();
        panel.setSize(400,300);
        panel.setLayout(null);
        frame.add(panel);
        nameLabel = new JLabel("Name:");
        nameLabel.setBounds(60,40,100,30);
        panel.add(nameLabel);
        dateLabel = new JLabel("Birthdate:");
        dateLabel.setBounds(60,80,100,30);
        panel.add(dateLabel);
        specLabel = new JLabel("Specialization:");
        specLabel.setBounds(60,120,100,30);
        panel.add(specLabel);
        passLabel = new JLabel("Password:");
        passLabel.setBounds(60,160,100,30);
        panel.add(passLabel);
        nameBox = new JTextField();
        nameBox.setBounds(170,40,150,30);
        panel.add(nameBox);
        dateBox = new JTextField();
        dateBox.setBounds(170,80,150,30);
        panel.add(dateBox);
        specBox = new JTextField();
        specBox.setBounds(170,120,150,30);
        panel.add(specBox);
        passBox = new JPasswordField();
        passBox.setBounds(170,160,150,30);
        panel.add(passBox);
        bConfirm = new JButton("Confirm");
        bConfirm.setBounds(150,220,100,30);
        panel.add(bConfirm);
        frame.setVisible(false);
    }
}
