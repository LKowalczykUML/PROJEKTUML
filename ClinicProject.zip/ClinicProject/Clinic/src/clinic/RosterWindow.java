/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Kowalczyk
 */
public class RosterWindow {
   
    JFrame frame;
    JPanel panel;
    JLabel[] headerTab;
    JTextField[][] boxTab;
    public RosterWindow(ArrayList<RosterEntry> t)
    {
        frame = new JFrame("Roster");
        frame.setLocation(0, 0);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setSize(1600,900);
        panel = new JPanel();
        panel.setLayout(null);
        panel.setSize(1600,900);
        frame.add(panel);
        headerTab = new JLabel[7];
        for(int i=0;i<7;i++)
        {
            if(i==0)
                headerTab[i] = new JLabel(t.get(0).visitDate.printDate());
            else
            {
                Date2 d = new Date2(t.get(0).visitDate);
                d.raise(i);
                headerTab[i] = new JLabel(d.printDate());
            }
            headerTab[i].setBounds(150+i*200,30,200,30);
            panel.add(headerTab[i]);
        }
        boxTab = new JTextField[7][24];
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<24;j++)
            {
                boxTab[i][j]= new JTextField(j+":00");
                boxTab[i][j].setBounds(i*200+130,70+j*30,200,30);
                boxTab[i][j].setEditable(false);
                panel.add(boxTab[i][j]);
            }
        }
        for(RosterEntry r:t)
        {
            Date2 d= new Date2(t.get(0).visitDate);
            int i=0;
            if(r.visitDate.equals(d))
            {
                boxTab[i][r.hour].setText(r.hour+":00 "+r.patientName);
            }
            else
            {
                while(!r.visitDate.equals(d) && i<7)
                {
                    d.raise(1);
                    i+=1;
                }
                if(i<7)
                {
                    boxTab[i][r.hour].setText(r.hour+":00 "+r.patientName);
                }
            }
        }
        frame.setVisible(true);
    }
    
}
