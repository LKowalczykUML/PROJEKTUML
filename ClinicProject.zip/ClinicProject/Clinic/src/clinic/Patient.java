/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

/**
 *
 * @author Kowalczyk
 */
public class Patient {
    private String name,birthdate;
    private int patientID;
    
    public Patient(String n, String BDay,int id)
    {
        name=n;
        patientID=id;
        birthdate=BDay;
    }

    public String getName() {
        return name;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public int getPatientID() {
        return patientID;
    }
}
