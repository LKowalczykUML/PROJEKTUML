/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

/**
 *
 * @author Kowalczyk
 */
public class RosterEntry implements Comparable<RosterEntry>{
    public String patientName;
    public Date2 visitDate;
    public int hour;
    
    public RosterEntry(String c,String s,int h)
    {
        visitDate=new Date2(c);
        patientName=s;
        hour=h;
    }

    @Override
    public int compareTo(RosterEntry r) {
        int d=r.visitDate.getDay();
        int m=r.visitDate.getMonth();
        int y=r.visitDate.getYear();
        
        if(y==this.visitDate.getYear())
        {
            if(m==this.visitDate.getMonth())
            {
                return this.visitDate.getDay()-d;
            }
            else
                return this.visitDate.getMonth()-m;
        }
        else
            return this.visitDate.getYear()-y;
        
    }
}
