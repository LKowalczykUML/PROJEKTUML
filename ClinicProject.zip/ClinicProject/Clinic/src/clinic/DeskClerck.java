/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic;

/**
 *
 * @author Kowalczyk
 */
public class DeskClerck extends User{
    
    int clerckID;
    
    public DeskClerck(String nm,String BDay,String Pass,int id)
    {
        super(nm,BDay,("C"+String.valueOf(id)),Pass);
        clerckID=id;
    }

    public int getClerckID() {
        return clerckID;
    }
    
}
